package hus.oop.book;

public interface MyBookComparator {
    int compare(Book left, Book right);
}
