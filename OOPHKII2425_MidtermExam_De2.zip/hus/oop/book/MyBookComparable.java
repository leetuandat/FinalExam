package hus.oop.book;

public interface MyBookComparable {
    int compareTo(Book another);
}
